<?php
/**
 * The template for displaying archive pages.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package BlogHash
 * @author Peregrine Themes
 * @since   1.0.0
 */

?>

<?php get_header(); ?>

<?php
// Проверяваме дали има custom страница за тази категория
$has_custom_page = false;
$custom_page_id = null;
$custom_page = null;

if (is_category()) {
    $category_id = get_queried_object_id();
    $custom_page_id = get_term_meta($category_id, 'category_custom_page', true);
    
    if (!empty($custom_page_id)) {
        $custom_page = get_post($custom_page_id);
        if ($custom_page && $custom_page->post_type === 'page' && in_array($custom_page->post_status, array('publish', 'private'))) {
            $has_custom_page = true;
        }
    }
}
?>

<?php if ($has_custom_page): ?>
    
    <?php 
    // Зареждаме custom страницата
    global $post;
    $original_post = $post;
    $post = $custom_page;
    setup_postdata($post);
    
    // Използваме BlogHash функциите за да вземем настройките
    $site_layout = bloghash_get_site_layout($custom_page_id);
    
    // Ако няма специфичен layout, проверяваме директно meta данните
    if (empty($site_layout) || $site_layout === 'default') {
        // Проверяваме различни възможни meta ключове
        $possible_meta_keys = array(
            'bloghash_content_layout',
            'bloghash_page_layout',
            '_bloghash_content_layout',
            'content_layout',
            'page_layout'
        );
        
        foreach ($possible_meta_keys as $meta_key) {
            $meta_value = get_post_meta($custom_page_id, $meta_key, true);
            if (!empty($meta_value) && $meta_value !== 'default') {
                $site_layout = $meta_value;
                break;
            }
        }
        
        // Ако все още няма layout, вземи от Customizer default
        if (empty($site_layout) || $site_layout === 'default') {
            $site_layout = bloghash_option('site_layout');
        }
    }
    
    $sidebar_position = bloghash_get_sidebar_position($custom_page_id);
    $has_sidebar = bloghash_is_sidebar_displayed($custom_page_id);
    
    // Debug информация (премахни след тестване)
    // error_log('Site Layout: ' . $site_layout);
    // error_log('Sidebar Position: ' . $sidebar_position);
    // error_log('Has Sidebar: ' . ($has_sidebar ? 'yes' : 'no'));
    
    // Проверяваме за Elementor
    $is_elementor = did_action("elementor/loaded");
    $page_template = get_page_template_slug($custom_page_id);
    $elementor_data = get_post_meta($custom_page_id, "_elementor_data", true);
    $elementor_edit_mode = get_post_meta($custom_page_id, "_elementor_edit_mode", true);
    $is_elementor_canvas = ($page_template === 'elementor_canvas' || $page_template === 'elementor_header_footer');
    
    // Определяме класовете
    $wrapper_classes = array('category-as-page-wrapper');
    
    // Site layout клас
    if ($site_layout) {
        $wrapper_classes[] = 'bloghash-layout__' . $site_layout;
    }
    
    // Sidebar класове
    if (!$has_sidebar) {
        $wrapper_classes[] = 'bloghash-no-sidebar';
    } else {
        $wrapper_classes[] = 'bloghash-has-sidebar';
        $wrapper_classes[] = 'bloghash-sidebar-position__' . $sidebar_position;
    }
    
    // Elementor класове
    if ($is_elementor_canvas) {
        $wrapper_classes[] = 'elementor-template-canvas';
    }
    
    // Вземаме категорийна информация
    $category = get_queried_object();
    $show_category_header = ($category && isset($category->name) && !$is_elementor_canvas);
    ?>
    
    <style>
    /* Премахваме стандартния page header за категории с custom страница */
    body.category.category-has-custom-page .bloghash-page-header {
        display: none !important;
    }
    
    /* Custom категорийно заглавие */
    .category-custom-header {
        padding: 60px 0 40px;
        text-align: center;
        background: #f8f9fa;
        margin-bottom: 50px;
    }
    
    .category-custom-header h1 {
        margin: 0 0 20px;
        font-size: 2.8rem;
        font-weight: 700;
        line-height: 1.2;
    }
    
    .category-custom-header .archive-description {
        max-width: 700px;
        margin: 0 auto;
        font-size: 1.1rem;
        color: #666;
        line-height: 1.6;
    }
    
    /* Full Width: Stretched - пълна ширина без padding */
    body.bloghash-layout__fw-stretched .category-as-page-wrapper.bloghash-layout__fw-stretched .bloghash-container,
    .category-as-page-wrapper.bloghash-layout__fw-stretched .bloghash-container {
        max-width: 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }
    
    body.bloghash-layout__fw-stretched .category-as-page-wrapper.bloghash-layout__fw-stretched #primary,
    .category-as-page-wrapper.bloghash-layout__fw-stretched #primary {
        max-width: 100% !important;
        padding-left: 0 !important;
        padding-right: 0 !important;
    }
    
    body.bloghash-layout__fw-stretched .category-as-page-wrapper.bloghash-layout__fw-stretched .entry-content,
    .category-as-page-wrapper.bloghash-layout__fw-stretched .entry-content {
        max-width: 100% !important;
    }
    
    /* Full Width: Contained - стандартен container width */
    body.bloghash-layout__fw-contained .category-as-page-wrapper.bloghash-layout__fw-contained .bloghash-container,
    .category-as-page-wrapper.bloghash-layout__fw-contained .bloghash-container {
        max-width: var(--bloghash-container, 1200px);
        padding-left: 15px;
        padding-right: 15px;
        margin-left: auto;
        margin-right: auto;
    }
    
    /* Sidebar класове */
    .category-as-page-wrapper.bloghash-no-sidebar #primary {
        max-width: 100% !important;
        width: 100% !important;
        flex: 0 0 100% !important;
    }
    
    .category-as-page-wrapper.bloghash-has-sidebar #primary {
        flex: 0 0 70% !important;
        max-width: 70% !important;
    }
    
    /* Комбинация: fw-stretched БЕЗ sidebar */
    .category-as-page-wrapper.bloghash-layout__fw-stretched.bloghash-no-sidebar #primary {
        max-width: 100% !important;
        width: 100% !important;
    }
    
    /* Комбинация: fw-contained БЕЗ sidebar */
    .category-as-page-wrapper.bloghash-layout__fw-contained.bloghash-no-sidebar #primary {
        max-width: 100% !important;
        width: 100% !important;
    }
    
    /* За Elementor canvas */
    .category-as-page-wrapper.elementor-template-canvas {
        margin: 0;
        padding: 0;
    }
    
    .category-as-page-wrapper.elementor-template-canvas .bloghash-container {
        max-width: 100% !important;
        padding: 0 !important;
    }
    
    /* Responsive */
    @media (max-width: 960px) {
        .category-as-page-wrapper #primary {
            max-width: 100% !important;
            width: 100% !important;
            flex: 0 0 100% !important;
        }
        
        .category-as-page-wrapper .bloghash-container {
            padding-left: 15px !important;
            padding-right: 15px !important;
        }
    }
    </style>
    
    <?php
    // Показваме категорийно заглавие само ако не е Elementor Canvas
    if ($show_category_header) : 
    ?>
        <div class="category-custom-header">
            <div class="bloghash-container">
                <h1><?php echo esc_html($category->name); ?></h1>
                <?php if ($category->description) : ?>
                    <div class="archive-description">
                        <?php echo wpautop($category->description); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>
    
    <?php if ($is_elementor_canvas): ?>
        
        <!-- Elementor Canvas - пълна ширина без container -->
        <div class="<?php echo esc_attr(implode(' ', $wrapper_classes)); ?>">
            <?php echo apply_filters('the_content', $custom_page->post_content); ?>
        </div>
        
    <?php else: ?>
        
        <!-- Стандартен BlogHash layout -->
        <?php do_action( 'bloghash_before_container' ); ?>

        <div class="bloghash-container <?php echo esc_attr(implode(' ', $wrapper_classes)); ?>">

            <?php do_action( 'bloghash_before_content_area', 'before_custom_page' ); ?>

            <div id="primary" class="content-area">

                <?php do_action( 'bloghash_before_content' ); ?>

                <main id="content" class="site-content" role="main"<?php bloghash_schema_markup( 'main' ); ?>>

                    <article id="post-<?php echo $custom_page_id; ?>" <?php post_class(); ?>>
                        <div class="entry-content bloghash-entry">
                            <?php echo apply_filters('the_content', $custom_page->post_content); ?>
                        </div>
                    </article>

                </main><!-- #content .site-content -->

                <?php do_action( 'bloghash_after_content' ); ?>

            </div><!-- #primary .content-area -->

            <?php 
            // Показваме sidebar само ако страницата има такъв
            if ($has_sidebar) {
                do_action( 'bloghash_sidebar' );
            }
            ?>

            <?php do_action( 'bloghash_after_content_area' ); ?>

        </div><!-- END .bloghash-container -->

        <?php do_action( 'bloghash_after_container' ); ?>
        
    <?php endif; ?>
    
    <?php 
    // Възстановяваме оригиналния post
    $post = $original_post;
    wp_reset_postdata();
    ?>

<?php else: ?>
    
    <!-- Стандартен archive template -->
    
    <?php do_action( 'bloghash_before_container' ); ?>

    <div class="bloghash-container">

        <?php do_action( 'bloghash_before_content_area', 'before_post_archive' ); ?>

        <div id="primary" class="content-area">

            <?php do_action( 'bloghash_before_content' ); ?>

            <main id="content" class="site-content" role="main"<?php bloghash_schema_markup( 'main' ); ?>>

                <?php do_action( 'bloghash_content_archive' ); ?>

            </main><!-- #content .site-content -->

            <?php do_action( 'bloghash_after_content' ); ?>

        </div><!-- #primary .content-area -->

        <?php do_action( 'bloghash_sidebar' ); ?>

        <?php do_action( 'bloghash_after_content_area' ); ?>

    </div><!-- END .bloghash-container -->

    <?php do_action( 'bloghash_after_container' ); ?>

<?php endif; ?>

<?php get_footer(); ?>