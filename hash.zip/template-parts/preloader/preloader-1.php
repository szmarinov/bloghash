<?php
/**
 * The template for displaying page preloader layout 1.
 *
 * @package BlogHash
 * @author Peregrine Themes
 * @since   1.0.0
 */

?>

<div class="preloader-1">
	<div></div>
</div><!-- END .bloghash-preloader-1 -->
